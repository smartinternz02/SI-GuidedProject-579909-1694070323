import pickle
from flask import Flask, render_template, request
import pandas as pd
import numpy as np

model = pickle.load(open('blue.pkl','rb'))
app=Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/details') # rendering the html template
def index() :
    return render_template('details.html')

@app.route('/predict', methods=['GET','POST'])
def predict() :
    # loading model which we saved
   
    MinOfUpperTRange= float(request.form['MinOfUpperTRange'])
    MaxOfLowerTRange= float(request.form['MaxOfLowerTRange'])
    MinOfLowerTRange= float(request.form['MinOfLowerTRange'])
    AverageOfUpperTRange= float(request.form['AverageOfUpperTRange'])
    AverageRainingDays= float(request.form['AverageRainingDays'])
    AverageOfLowerTRange = float(request.form['AverageOfLowerTRange'])
    MaxOfUpperTRange= float(request.form['MaxOfUpperTRange'])
    clonesize= float(request.form['clonesize'])
    Honeybees= float(request.form['Honeybees'])
    
   
    


    prediction =model.predict(pd.DataFrame([[ MinOfUpperTRange, MaxOfLowerTRange, MinOfLowerTRange, AverageOfUpperTRange, AverageRainingDays, AverageOfLowerTRange, MaxOfUpperTRange,clonesize, Honeybees]], columns=['MinOfUpperTRange', 'MaxOfLowerTRange', 'MinOfLowerTRange', 'AverageOfUpperTRange', 'AverageRainingDays','AverageOfLowerTRange','MaxOfUpperTRange','clonesize','Honeybees']))
    
    prediction=int(prediction)
    
    
    return render_template('predict.html', prediction_text ="{}".format(prediction))



if __name__ == "__main__":
    app.run()